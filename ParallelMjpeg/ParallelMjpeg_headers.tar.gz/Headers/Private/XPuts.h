#ifndef XPUTS_H
#define XPUTS_H

//extern uint32_t TTY_DEVICE;

extern void xputs (char * s);

#endif
