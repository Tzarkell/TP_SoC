#ifndef ITOA_H
#define ITOA_H

#include <stdint.h>

extern int32_t itoa (int32_t integer, char * buffer);

#endif
