void * mymemcpy(void *dst, const void *src, const size_t len);
